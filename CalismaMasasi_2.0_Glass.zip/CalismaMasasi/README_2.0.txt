ÇALIŞMA MASASI 2.0 — GLASS EDITION

Bu proje, sağlanan Çalışma Masası Android kaynak projesinin mevcut işlevleri korunarak
Glassmorphism arayüzüyle yenilenmiş sürümüdür.

Arayüz yenilikleri:
- Cam görünümlü yarı saydam paneller ve ince kenarlıklar
- Mor/mavi ışık geçişli arka plan
- Yenilenmiş alt navigasyon çubuğu
- Çalışma sayacı ve Pomodoro ekranında yeni kart düzeni
- Haftalık program, deneme, soru defteri ve ayarlar ekranlarında görsel yenileme
- Açık/koyu tema ve vurgu rengi seçenekleri korunmuştur

Korunan özellikler:
- LGS/YKS seçimi ve sınav tarihi
- Çalışma sayacı, Pomodoro ve çalışma kayıtları
- Odak modu ve seçilen uygulamaları engelleme servisi
- Haftalık ders programı, hatırlatmalar ve tamamlandı işaretleme
- Deneme sayacı ve takvim
- Soru defteri, kamera/galeri ve PDF dışa aktarma
- Ana ekran widget'ı ve bildirim altyapısı

Projeyi Android Studio'da açmak için CalismaMasasi klasörünü seç.
JDK 17 ve Android SDK 34 gereklidir.

Not: Bu paket kaynak projedir; APK dosyası değildir.
