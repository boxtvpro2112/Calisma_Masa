package com.example.calisma

import android.content.Context
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import androidx.compose.ui.platform.LocalContext

@Composable
fun ExamPicker(prefs: Prefs) {
    GlassBackdrop {
        Column(
            Modifier.fillMaxSize().background(Color.Transparent).systemBarsPadding()
                .padding(horizontal = 24.dp, vertical = 30.dp),
            verticalArrangement = Arrangement.Center
        ) {
            Text("ÇALIŞMA MASASI", color = MaterialTheme.colorScheme.primary,
                fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
            Spacer(Modifier.height(14.dp))
            Text("Hedefini seç.", fontSize = 34.sp, lineHeight = 40.sp,
                fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
            Spacer(Modifier.height(8.dp))
            Text("Derslerini ve çalışma alanını sana göre hazırlayalım.",
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(30.dp))
            Exam.values().forEach { e ->
                GlassPanel(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 14.dp),
                    radius = 24.dp,
                    contentPadding = PaddingValues(22.dp)
                ) {
                    Column(Modifier.fillMaxWidth().clickable { prefs.chooseExam(e) }) {
                        Text(e.label, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(4.dp))
                        Text(if (e == Exam.LGS) "8. sınıf · Ortaokul" else "TYT ve AYT · Lise",
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(Modifier.height(12.dp))
                        Text("Devam et  →", color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
    }
}

private enum class Tab(val label: String, val icon: ImageVector) {
    STUDY("Çalışma", Icons.Filled.Home),
    TODO("Program", Icons.Filled.Check),
    TEST("Deneme", Icons.Filled.Star),
    NOTES("Defter", Icons.Filled.Edit),
    SETTINGS("Ayarlar", Icons.Filled.Settings)
}

@Composable
fun MainShell(prefs: Prefs, data: Data) {
    var tab by remember { mutableStateOf(Tab.STUDY) }
    val ctx = LocalContext.current
    val studyClock = remember { Clock(ctx.getSharedPreferences("clock", Context.MODE_PRIVATE), "study") }
    val examClock = remember { Clock(ctx.getSharedPreferences("clock", Context.MODE_PRIVATE), "exam") }

    LaunchedEffect(Unit) { data.syncOnline() }
    LaunchedEffect(prefs.focusOn) {
        if (prefs.focusOn && FocusPerms.allGranted(ctx)) FocusGuard.start(ctx)
        else {
            FocusGuard.stop(ctx)
            if (prefs.focusOn) prefs.setFocus(false)
        }
    }
    LaunchedEffect(FocusBus.tick) { if (FocusBus.tick > 0) tab = Tab.STUDY }
    LaunchedEffect(studyClock.running, studyClock.label) {
        Notifs.timer(ctx, studyClock.running, studyClock.label, studyClock.startedAt, studyClock.accum)
    }
    LaunchedEffect(studyClock.running, examClock.running) {
        while (studyClock.running || examClock.running) {
            val n = System.currentTimeMillis()
            studyClock.now = n
            examClock.now = n
            delay(500)
        }
    }

    GlassBackdrop {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = Color.Transparent,
            bottomBar = {
                Box(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp)) {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(26.dp),
                        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.88f),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.22f)),
                        shadowElevation = 14.dp,
                        tonalElevation = 0.dp
                    ) {
                        NavigationBar(
                            containerColor = Color.Transparent,
                            tonalElevation = 0.dp,
                        ) {
                            Tab.values().forEach { t ->
                                NavigationBarItem(
                                    selected = tab == t,
                                    onClick = { tab = t },
                                    icon = {
                                        Icon(t.icon, contentDescription = t.label,
                                            modifier = Modifier.size(21.dp))
                                    },
                                    label = { Text(t.label, fontSize = 10.sp, maxLines = 1) },
                                    alwaysShowLabel = true,
                                    colors = NavigationBarItemDefaults.colors(
                                        indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.18f),
                                        selectedIconColor = MaterialTheme.colorScheme.primary,
                                        selectedTextColor = MaterialTheme.colorScheme.primary,
                                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                )
                            }
                        }
                    }
                }
            }
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when (tab) {
                    Tab.SETTINGS -> SettingsScreen(prefs)
                    Tab.STUDY -> StudyScreen(prefs, data, studyClock)
                    Tab.TODO -> TodoScreen(data)
                    Tab.TEST -> TestScreen(prefs, data, examClock)
                    Tab.NOTES -> NotebookScreen(prefs, data)
                }
            }
        }
    }
}

@Composable
fun Placeholder(title: String) {
    Column(Modifier.fillMaxSize().statusBarsPadding().padding(24.dp)) {
        Text(title, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("Bu ekran sonraki adımda eklenecek.",
            color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun SettingsScreen(prefs: Prefs) {
    Column(
        Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState())
            .padding(horizontal = 22.dp, vertical = 18.dp)
    ) {
        Text("Kişiselleştir", fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Text("Çalışma alanını kendine göre düzenle.",
            color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(22.dp))

        GlassPanel(Modifier.fillMaxWidth()) {
            Text("Sınav hedefi", fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Exam.values().forEach { e ->
                    FilterChip(selected = prefs.exam == e, onClick = { prefs.chooseExam(e) },
                        label = { Text(e.label) })
                }
            }
        }
        Spacer(Modifier.height(14.dp))
        GlassPanel(Modifier.fillMaxWidth()) {
            Text("Görünüm", fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Spacer(Modifier.height(5.dp))
            Text("Açık, koyu veya cihaz ayarını kullan.",
                color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                Mode.values().forEach { m ->
                    FilterChip(selected = prefs.mode == m, onClick = { prefs.chooseMode(m) },
                        label = { Text(m.label) })
                }
            }
            Spacer(Modifier.height(18.dp))
            Text("Vurgu rengi", fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                Accents.forEachIndexed { i, a ->
                    val selected = prefs.accent == i
                    Box(
                        Modifier.size(42.dp).clip(CircleShape).background(a.light)
                            .then(if (selected) Modifier.border(3.dp, MaterialTheme.colorScheme.onBackground, CircleShape) else Modifier)
                            .clickable { prefs.chooseAccent(i) },
                        contentAlignment = Alignment.Center
                    ) {
                        if (selected) Icon(Icons.Filled.Check, contentDescription = a.name,
                            tint = Color.White, modifier = Modifier.size(19.dp))
                    }
                }
            }
        }
        Spacer(Modifier.height(14.dp))
        GlassPanel(Modifier.fillMaxWidth()) {
            Text("Çalışma Masası 2.0", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text("Cam yüzeyler, yumuşak ışıklar ve sade bir çalışma alanı.",
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.height(16.dp))
    }
}
