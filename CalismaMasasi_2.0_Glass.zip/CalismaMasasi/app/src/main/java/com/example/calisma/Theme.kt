package com.example.calisma

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

class AccentColor(val name: String, val light: Color, val dark: Color)

val Accents = listOf(
    AccentColor("Mavi", Color(0xFF3979F6), Color(0xFF9DBBFF)),
    AccentColor("Yeşil", Color(0xFF168B70), Color(0xFF8BE0C5)),
    AccentColor("Mor", Color(0xFF7956E8), Color(0xFFC1B0FF)),
    AccentColor("Turuncu", Color(0xFFC66A32), Color(0xFFFFC18E)),
)

@Composable
fun AppTheme(prefs: Prefs, content: @Composable () -> Unit) {
    val dark = when (prefs.mode) {
        Mode.SYSTEM -> isSystemInDarkTheme()
        Mode.LIGHT -> false
        Mode.DARK -> true
    }
    val accent = Accents[prefs.accent]
    val scheme = if (dark) darkColorScheme(
        primary = accent.dark,
        onPrimary = Color(0xFF171329),
        secondary = Color(0xFF83C8FF),
        onSecondary = Color(0xFF071526),
        tertiary = Color(0xFFFFA7D5),
        background = Color(0xFF090B16),
        surface = Color(0xFF171A2B),
        surfaceVariant = Color(0xFF252A42),
        onBackground = Color(0xFFF3F1FF),
        onSurface = Color(0xFFF3F1FF),
        onSurfaceVariant = Color(0xFFB8BCD2),
        outline = Color(0xFF8B91B5)
    ) else lightColorScheme(
        primary = accent.light,
        onPrimary = Color.White,
        secondary = Color(0xFF2879B8),
        tertiary = Color(0xFF9A5AC5),
        background = Color(0xFFEFF2FA),
        surface = Color(0xFFF8F9FF),
        surfaceVariant = Color(0xFFE4E8F4),
        onBackground = Color(0xFF17192A),
        onSurface = Color(0xFF17192A),
        onSurfaceVariant = Color(0xFF555C75),
        outline = Color(0xFF8991AB)
    )
    MaterialTheme(colorScheme = scheme, content = content)
}
