package com.example.calisma

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface

@Composable
fun GlassBackdrop(content: @Composable () -> Unit) {
    val dark = MaterialTheme.colorScheme.background
    val middle = if (dark.red < 0.5f) Color(0xFF17152D) else Color(0xFFE7E9F8)
    val violetGlow = if (dark.red < 0.5f) Color(0x557D5CFF) else Color(0x227D5CFF)
    val blueGlow = if (dark.red < 0.5f) Color(0x333B9DFF) else Color(0x223B9DFF)
    Box(
        Modifier
            .fillMaxSize()
            .background(
                Brush.linearGradient(
                    colors = listOf(
                        dark,
                        MaterialTheme.colorScheme.surface,
                        middle,
                        dark
                    )
                )
            )
            .drawBehind {
                drawCircle(
                    brush = Brush.radialGradient(
                        listOf(violetGlow, Color.Transparent),
                        center = Offset(size.width * 0.92f, size.height * 0.08f),
                        radius = maxOf(size.width, size.height) * 0.62f
                    ),
                    radius = maxOf(size.width, size.height) * 0.62f,
                    center = Offset(size.width * 0.92f, size.height * 0.08f)
                )
                drawCircle(
                    brush = Brush.radialGradient(
                        listOf(blueGlow, Color.Transparent),
                        center = Offset(size.width * 0.02f, size.height * 0.72f),
                        radius = maxOf(size.width, size.height) * 0.58f
                    ),
                    radius = maxOf(size.width, size.height) * 0.58f,
                    center = Offset(size.width * 0.02f, size.height * 0.72f)
                )
            }
    ) { content() }
}

@Composable
fun GlassPanel(
    modifier: Modifier = Modifier,
    radius: Dp = 24.dp,
    contentPadding: PaddingValues = PaddingValues(18.dp),
    content: @Composable () -> Unit
) {
    val shape = RoundedCornerShape(radius)
    Surface(
        modifier = modifier.border(
            BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.24f)),
            shape
        ),
        shape = shape,
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.76f),
        tonalElevation = 0.dp,
        shadowElevation = 8.dp
    ) {
        Box(Modifier.padding(contentPadding)) { content() }
    }
}
