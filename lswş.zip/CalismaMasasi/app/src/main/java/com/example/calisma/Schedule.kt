package com.example.calisma

import android.app.TimePickerDialog
import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.time.LocalDate

private val dayNames = listOf("Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma", "Cumartesi", "Pazar")
private val dayShort = listOf("Pzt", "Sal", "Çar", "Per", "Cum", "Cmt", "Paz")

fun fmtTime(min: Int): String = "%02d:%02d".format(min / 60, min % 60)

fun pickTime(ctx: Context, initial: Int, onPick: (Int) -> Unit) {
    TimePickerDialog(ctx, { _, h, m -> onPick(h * 60 + m) }, initial / 60, initial % 60, true).show()
}

@Composable
fun SchedulePane(data: Data) {
    val ctx = LocalContext.current
    val today = LocalDate.now().dayOfWeek.value
    val week = weekStart()
    var showEditor by remember { mutableStateOf(false) }
    var editingId by remember { mutableStateOf<Long?>(null) }
    var subject by remember { mutableStateOf("") }
    var topic by remember { mutableStateOf("") }
    var day by remember { mutableIntStateOf(today) }
    var start by remember { mutableIntStateOf(18 * 60) }
    var end by remember { mutableIntStateOf(19 * 60) }
    var remind by remember { mutableStateOf(false) }

    // Günlere göre gruplama sadece bloklar değişince yapılır, her kaydırmada değil.
    val byDay by remember { derivedStateOf { data.blocks.groupBy { it.day }.mapValues { e -> e.value.sortedBy { it.start } } } }

    fun newBlock() {
        editingId = null
        subject = ""
        topic = ""
        day = today
        start = 18 * 60
        end = 19 * 60
        remind = false
        showEditor = true
    }

    fun editBlock(b: Block) {
        editingId = b.id
        subject = b.title
        topic = b.topic
        day = b.day
        start = b.start
        end = b.end
        remind = b.remind
        showEditor = true
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Haftalık program", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("Programını kendin oluştur.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Button(onClick = { newBlock() }) { Text("Blok ekle") }
        }
        Spacer(Modifier.height(12.dp))
        if (data.blocks.isEmpty()) {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = MaterialTheme.colorScheme.surfaceVariant,
                shape = MaterialTheme.shapes.large
            ) {
                Column(Modifier.padding(20.dp)) {
                    Text("Haftalık tablon boş", fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(4.dp))
                    Text("Bir gün ve saat seçerek ilk ders bloğunu ekleyebilirsin.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        LazyColumn(Modifier.fillMaxWidth()) {
            for (d in 1..7) {
                val list = byDay[d] ?: emptyList()
                item(key = "h$d", contentType = "header") {
                    Text(
                        dayNames[d - 1], fontWeight = FontWeight.SemiBold,
                        color = if (d == today) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onBackground,
                        modifier = Modifier.padding(top = 14.dp, bottom = 6.dp)
                    )
                }
                if (list.isEmpty()) {
                    item(key = "e$d", contentType = "empty") {
                        Text("Henüz blok eklenmedi", color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(start = 4.dp, bottom = 6.dp))
                    }
                }
                items(list, key = { it.id }, contentType = { "block" }) { b ->
                    BlockRow(b, b.doneWeek == week, onToggle = { data.toggleBlock(b.id) },
                        onEdit = { editBlock(b) }, onDelete = { data.removeBlock(b.id) })
                }
            }
        }
    }

    if (showEditor) {
        AlertDialog(
            onDismissRequest = { showEditor = false },
            title = { Text(if (editingId == null) "Yeni blok" else "Bloğu düzenle") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    OutlinedTextField(
                        value = subject, onValueChange = { subject = it }, singleLine = true,
                        label = { Text("Ders") }, placeholder = { Text("Örn. Matematik") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = topic, onValueChange = { topic = it }, singleLine = false,
                        label = { Text("Konu") }, placeholder = { Text("Örn. Üslü sayılar") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(14.dp))
                    Text("Gün", fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(6.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        dayShort.chunked(4).forEachIndexed { rowIndex, row ->
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                row.forEachIndexed { colIndex, label ->
                                    val index = rowIndex * 4 + colIndex + 1
                                    FilterChip(selected = day == index, onClick = { day = index },
                                        label = { Text(label) })
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { pickTime(ctx, start) { start = it } }) {
                            Text("Başlangıç ${fmtTime(start)}")
                        }
                        OutlinedButton(onClick = { pickTime(ctx, end) { end = it } }) {
                            Text("Bitiş ${fmtTime(end)}")
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Haftalık hatırlatma", Modifier.weight(1f))
                        Switch(checked = remind, onCheckedChange = { remind = it })
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (subject.isNotBlank() && end > start) {
                        val id = editingId
                        if (id == null) data.addBlock(day, start, end, subject.trim(), remind, topic.trim())
                        else data.updateBlock(id, day, start, end, subject.trim(), remind, topic.trim())
                        showEditor = false
                    }
                }, enabled = subject.isNotBlank() && end > start) { Text("Kaydet") }
            },
            dismissButton = { TextButton(onClick = { showEditor = false }) { Text("İptal") } }
        )
    }
}

@Composable
private fun BlockRow(b: Block, done: Boolean, onToggle: () -> Unit, onEdit: () -> Unit, onDelete: () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        shape = MaterialTheme.shapes.medium
    ) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = done, onCheckedChange = { onToggle() })
            Column(Modifier.weight(1f)) {
                Text(b.title, fontWeight = FontWeight.SemiBold)
                if (b.topic.isNotBlank()) {
                    Text(b.topic, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Text(
                    "${fmtTime(b.start)}–${fmtTime(b.end)}",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.bodySmall
                )
            }
            IconButton(onClick = onEdit) { Icon(Icons.Filled.Edit, contentDescription = "Düzenle") }
            IconButton(onClick = onDelete) { Icon(Icons.Filled.Close, contentDescription = "Sil") }
        }
    }
}
