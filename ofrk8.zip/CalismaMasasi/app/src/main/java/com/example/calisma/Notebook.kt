package com.example.calisma

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.FileProvider

fun loadBitmap(path: String, maxSize: Int): Bitmap? {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(path, bounds)
    if (bounds.outWidth <= 0) return null
    var sample = 1
    while (bounds.outWidth / sample > maxSize * 2 || bounds.outHeight / sample > maxSize * 2) sample *= 2
    val opts = BitmapFactory.Options().apply { inSampleSize = sample }
    val bmp = BitmapFactory.decodeFile(path, opts) ?: return null
    val rot = when (runCatching {
        ExifInterface(path).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)
    }.getOrDefault(1)) {
        6 -> 90f
        3 -> 180f
        8 -> 270f
        else -> 0f
    }
    return if (rot == 0f) bmp
    else Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(rot) }, true)
}

@Composable
fun NotebookScreen(prefs: Prefs, data: Data) {
    val exam = prefs.exam ?: Exam.LGS
    val ctx: Context = LocalContext.current
    val subjects = subjectsFor(exam)
    var filter by remember(exam) { mutableStateOf<String?>(null) }
    var query by remember { mutableStateOf("") }
    var pendingId by rememberSaveable { mutableStateOf<Long?>(null) }
    var cameraId by rememberSaveable { mutableStateOf<Long?>(null) }
    var viewing by remember { mutableStateOf<Question?>(null) }

    val gallery = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val id = System.currentTimeMillis()
            val ok = runCatching {
                ctx.contentResolver.openInputStream(uri)!!.use { input ->
                    data.imageFile(id).outputStream().use { out -> input.copyTo(out) }
                }
            }.isSuccess
            if (ok) pendingId = id
        }
    }
    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val id = cameraId
        if (id != null) {
            if (ok) pendingId = id else data.imageFile(id).delete()
        }
        cameraId = null
    }

    val list = data.questions
        .filter { (filter == null || it.subject == filter) && (query.isBlank() || it.note.contains(query, ignoreCase = true)) }
        .sortedByDescending { it.id }

    Column(Modifier.fillMaxSize().statusBarsPadding().padding(24.dp)) {
        Text("Soru Defteri", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = { gallery.launch("image/*") }) { Text("Galeriden ekle") }
            Button(onClick = {
                val id = System.currentTimeMillis()
                val f = data.imageFile(id)
                runCatching { f.createNewFile() }
                cameraId = id
                camera.launch(FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", f))
            }) { Text("Fotoğraf çek") }
        }
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = query, onValueChange = { query = it }, singleLine = true,
            placeholder = { Text("Notlarda ara") }, modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = filter == null, onClick = { filter = null }, label = { Text("Tümü") })
            subjects.forEach { s ->
                FilterChip(selected = filter == s, onClick = { filter = s }, label = { Text(s) })
            }
        }
        Spacer(Modifier.height(12.dp))
        if (list.isEmpty()) {
            Text(
                if (data.questions.isEmpty()) "Henüz soru yok. Çözemediğin bir soruyu ekle." else "Sonuç yok.",
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
            )
        }
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(list, key = { it.id }) { q ->
                val bmp = remember(q.id) { loadBitmap(data.imageFile(q.id).path, 500) }
                Surface(
                    onClick = { viewing = q },
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant
                ) {
                    Column {
                        if (bmp != null) {
                            Image(
                                bitmap = bmp.asImageBitmap(), contentDescription = q.subject,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxWidth().height(140.dp)
                            )
                        }
                        Column(Modifier.padding(10.dp)) {
                            Text(q.subject, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            if (q.note.isNotBlank()) {
                                Text(q.note, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
                            }
                        }
                    }
                }
            }
        }
    }

    pendingId?.let { id ->
        var subj by remember(id) { mutableStateOf(subjects.first()) }
        var note by remember(id) { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { data.imageFile(id).delete(); pendingId = null },
            title = { Text("Soruyu kaydet") },
            text = {
                Column {
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        subjects.forEach { s ->
                            FilterChip(selected = subj == s, onClick = { subj = s }, label = { Text(s) })
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(
                        value = note, onValueChange = { note = it }, minLines = 2,
                        placeholder = { Text("Not (konu, neden yanlış yaptım...)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { data.addQuestion(id, subj, note.trim()); pendingId = null }) { Text("Kaydet") }
            },
            dismissButton = {
                TextButton(onClick = { data.imageFile(id).delete(); pendingId = null }) { Text("İptal") }
            }
        )
    }

    viewing?.let { q ->
        var scale by remember(q.id) { mutableFloatStateOf(1f) }
        var offset by remember(q.id) { mutableStateOf(Offset.Zero) }
        var confirm by remember(q.id) { mutableStateOf(false) }
        val bmp = remember(q.id) { loadBitmap(data.imageFile(q.id).path, 2000) }
        Dialog(onDismissRequest = { viewing = null }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
            Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                Column(Modifier.statusBarsPadding().navigationBarsPadding().padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("${q.subject} · ${fmtDate(q.day)}", Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                        TextButton(onClick = { viewing = null }) { Text("Kapat") }
                    }
                    if (bmp != null) {
                        Image(
                            bitmap = bmp.asImageBitmap(), contentDescription = q.subject,
                            contentScale = ContentScale.Fit,
                            modifier = Modifier.weight(1f).fillMaxWidth().clipToBounds()
                                .pointerInput(q.id) {
                                    detectTransformGestures { _, pan, zoom, _ ->
                                        scale = (scale * zoom).coerceIn(1f, 5f)
                                        offset = if (scale == 1f) Offset.Zero else offset + pan
                                    }
                                }
                                .graphicsLayer(scaleX = scale, scaleY = scale, translationX = offset.x, translationY = offset.y)
                        )
                    } else {
                        Spacer(Modifier.weight(1f))
                    }
                    if (q.note.isNotBlank()) {
                        Spacer(Modifier.height(8.dp))
                        Text(q.note)
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        TextButton(onClick = {
                            if (confirm) { data.removeQuestion(q.id); viewing = null } else confirm = true
                        }) { Text(if (confirm) "Silmek için tekrar dokun" else "Sil") }
                    }
                }
            }
        }
    }
}
