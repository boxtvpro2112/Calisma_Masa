plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}
android {
    namespace = "com.example.calisma"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.example.calisma.glass"
        minSdk = 26
        targetSdk = 34
        versionCode = 2
        versionName = "2.0 Glass"
    }
    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"))
            // Kendi telefonuna kurabilmen için debug anahtarıyla imzalanır.
            signingConfig = signingConfigs.getByName("debug")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.00"))
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material:material-icons-core")
    // Compose kütüphanelerinin hazır "baseline profile"ını kurulumda uygular: ilk açılış ve kaydırma daha akıcı olur.
    implementation("androidx.profileinstaller:profileinstaller:1.3.1")
}
