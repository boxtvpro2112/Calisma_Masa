package com.example.calisma

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import android.content.Context
import androidx.compose.ui.platform.LocalContext

@Composable
fun ExamPicker(prefs: Prefs) {
    Column(
        Modifier.fillMaxSize()
            .systemBarsPadding().padding(28.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Surface(shape = RoundedCornerShape(20.dp), color = MaterialTheme.colorScheme.primary, modifier = Modifier.size(60.dp)) {
            Box(contentAlignment = Alignment.Center) {
                Icon(Icons.Filled.Star, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(30.dp))
            }
        }
        Spacer(Modifier.height(28.dp))
        Text("Hangi sınava hazırlanıyorsun?", fontSize = 32.sp, fontWeight = FontWeight.Bold,
            lineHeight = 38.sp, letterSpacing = (-0.8).sp, color = MaterialTheme.colorScheme.onBackground)
        Spacer(Modifier.height(10.dp))
        Text("Ders listesi buna göre gelir. Sonra ayarlardan değiştirebilirsin.",
            color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(32.dp))
        Exam.values().forEach { e ->
            Surface(
                onClick = { prefs.chooseExam(e) },
                shape = MaterialTheme.shapes.large,
                color = MaterialTheme.colorScheme.surfaceVariant,
                border = cardBorder(),
                modifier = Modifier.fillMaxWidth().padding(bottom = 14.dp)
            ) {
                Row(Modifier.padding(22.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(e.label, fontSize = 26.sp, fontWeight = FontWeight.Bold, letterSpacing = (-0.4).sp)
                        Spacer(Modifier.height(2.dp))
                        Text(if (e == Exam.LGS) "8. sınıf, ortaokul" else "TYT ve AYT, lise",
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primaryContainer, modifier = Modifier.size(40.dp)) {
                        Box(contentAlignment = Alignment.Center) {
                            Text("→", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                        }
                    }
                }
            }
        }
    }
}

private enum class Tab(val label: String, val icon: ImageVector) {
    STUDY("Çalışma", Icons.Filled.Home),
    TODO("Yapılacaklar", Icons.Filled.Check),
    TEST("Deneme", Icons.Filled.Star),
    NOTES("Defter", Icons.Filled.Edit),
    SETTINGS("Ayarlar", Icons.Filled.Settings)
}

@Composable
fun MainShell(prefs: Prefs, data: Data) {
    var tab by remember { mutableStateOf(Tab.STUDY) }
    val ctx = LocalContext.current
    val studyClock = remember { Clock(ctx.getSharedPreferences("clock", Context.MODE_PRIVATE), "study") }
    val examClock = remember { Clock(ctx.getSharedPreferences("clock", Context.MODE_PRIVATE), "exam") }
    LaunchedEffect(Unit) { data.syncOnline() }
    // Odak modu: açıkken engelleme servisi çalışır, kapanınca durur.
    LaunchedEffect(prefs.focusOn) {
        if (prefs.focusOn && FocusPerms.allGranted(ctx)) FocusGuard.start(ctx)
        else { FocusGuard.stop(ctx); if (prefs.focusOn) prefs.setFocus(false) }
    }
    // Engellenen uygulama açılınca Çalışma sekmesine dön.
    LaunchedEffect(FocusBus.tick) { if (FocusBus.tick > 0) tab = Tab.STUDY }
    LaunchedEffect(studyClock.running, studyClock.label) {
        Notifs.timer(ctx, studyClock.running, studyClock.label, studyClock.startedAt, studyClock.accum)
    }
    LaunchedEffect(studyClock.running, examClock.running) {
        while (studyClock.running || examClock.running) {
            val n = System.currentTimeMillis()
            studyClock.now = n
            examClock.now = n
            delay(500)
        }
    }
    Scaffold(
        containerColor = Color.Transparent,
        contentColor = MaterialTheme.colorScheme.onBackground,
        bottomBar = {
            Column {
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                NavigationBar(containerColor = Color.Transparent, tonalElevation = 0.dp) {
                    Tab.values().forEach { t ->
                        NavigationBarItem(
                            selected = tab == t, onClick = { tab = t },
                            icon = { Icon(t.icon, contentDescription = t.label) },
                            label = { Text(t.label, fontSize = 11.sp, fontWeight = if (tab == t) FontWeight.SemiBold else FontWeight.Normal) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
                                selectedTextColor = MaterialTheme.colorScheme.onSurface,
                                indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                                unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                    }
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                Tab.SETTINGS -> SettingsScreen(prefs)
                Tab.STUDY -> StudyScreen(prefs, data, studyClock)
                Tab.TODO -> TodoScreen(data)
                Tab.TEST -> TestScreen(prefs, data, examClock)
                Tab.NOTES -> NotebookScreen(prefs, data)
            }
        }
    }
}

@Composable
fun Placeholder(title: String) {
    Column(Modifier.fillMaxSize().statusBarsPadding().padding(24.dp)) {
        Text(title, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("Bu ekran sonraki adımda eklenecek.",
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.65f))
    }
}

@Composable
private fun SettingsCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Surface(
        shape = MaterialTheme.shapes.large,
        color = MaterialTheme.colorScheme.surfaceVariant,
        border = cardBorder(),
        modifier = Modifier.fillMaxWidth().padding(bottom = 14.dp)
    ) {
        Column(Modifier.padding(18.dp)) {
            Text(title, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(12.dp))
            content()
        }
    }
}

@Composable
fun SettingsScreen(prefs: Prefs) {
    val ctx = LocalContext.current
    val version = remember { runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull() ?: "2.0" }
    Column(Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(24.dp)) {
        Text("Ayarlar", fontSize = 30.sp, fontWeight = FontWeight.Bold, letterSpacing = (-0.8).sp)
        Spacer(Modifier.height(20.dp))

        SettingsCard("Sınav") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Exam.values().forEach { e ->
                    AppChip(selected = prefs.exam == e, onClick = { prefs.chooseExam(e) }, label = { Text(e.label) })
                }
            }
        }

        SettingsCard("Tema") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Mode.values().forEach { m ->
                    AppChip(selected = prefs.mode == m, onClick = { prefs.chooseMode(m) }, label = { Text(m.label) })
                }
            }
        }

        SettingsCard("Renk") {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Accents.forEachIndexed { i, a ->
                    val selected = prefs.accent == i
                    Box(
                        Modifier.size(52.dp).clip(CircleShape)
                            .border(2.dp, if (selected) a.light else Color.Transparent, CircleShape)
                            .clickable { prefs.chooseAccent(i) }.padding(5.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(Modifier.fillMaxSize().clip(CircleShape).background(a.light), contentAlignment = Alignment.Center) {
                            if (selected) Icon(Icons.Filled.Check, contentDescription = a.name, tint = Color.White)
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(4.dp))
        Text("Çalışma Masası · Sürüm $version", style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.align(Alignment.CenterHorizontally))
    }
}
