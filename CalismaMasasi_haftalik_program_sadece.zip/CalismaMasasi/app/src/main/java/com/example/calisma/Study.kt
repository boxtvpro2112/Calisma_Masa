package com.example.calisma

import android.app.DatePickerDialog
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.provider.Settings
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.Locale

class Clock(private val sp: SharedPreferences, private val key: String) {
    var accum by mutableIntStateOf(sp.getInt("$key.accum", 0))
    var startedAt by mutableLongStateOf(sp.getLong("$key.start", 0L))
    var now by mutableLongStateOf(System.currentTimeMillis())
    var running by mutableStateOf(sp.getBoolean("$key.run", false))
    var label by mutableStateOf(sp.getString("$key.label", "") ?: "")
    var pomodoro by mutableStateOf(sp.getBoolean("$key.pomo", false))

    private fun save() {
        sp.edit().putInt("$key.accum", accum).putLong("$key.start", startedAt)
            .putBoolean("$key.run", running).putString("$key.label", label)
            .putBoolean("$key.pomo", pomodoro).apply()
    }

    fun elapsed(): Int = accum + if (running) ((now - startedAt) / 1000).toInt().coerceAtLeast(0) else 0
    fun start(newLabel: String = label) { label = newLabel; startedAt = System.currentTimeMillis(); now = startedAt; running = true; save() }
    fun pause() { accum = elapsed(); running = false; save() }
    fun reset() { accum = 0; running = false; save() }
    fun finishAt(total: Int) { accum = total; running = false; save() }
    fun usePomodoro(v: Boolean) { pomodoro = v; save() }
}

fun subjectsFor(exam: Exam): List<String> = if (exam == Exam.LGS)
    listOf("Türkçe", "Matematik", "Fen Bilimleri", "İnkılap Tarihi", "Din Kültürü", "İngilizce")
else
    listOf("Türkçe", "Matematik", "Geometri", "Fizik", "Kimya", "Biyoloji", "Edebiyat", "Tarih", "Coğrafya", "Felsefe")

fun fmtDur(sec: Int): String {
    val h = sec / 3600; val m = (sec % 3600) / 60
    return if (h > 0) "$h sa $m dk" else "$m dk"
}

fun fmtClock(sec: Int): String {
    val s = maxOf(sec, 0); val h = s / 3600; val m = (s % 3600) / 60; val x = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, x) else "%02d:%02d".format(m, x)
}

fun fmtDate(iso: String): String = runCatching {
    LocalDate.parse(iso).format(DateTimeFormatter.ofPattern("d MMMM yyyy", Locale("tr")))
}.getOrDefault(iso)

fun daysUntil(iso: String): Long = ChronoUnit.DAYS.between(LocalDate.now(), LocalDate.parse(iso))

fun pickDate(ctx: Context, onPick: (String) -> Unit) {
    val t = LocalDate.now()
    DatePickerDialog(ctx, { _, y, m, d -> onPick(LocalDate.of(y, m + 1, d).toString()) },
        t.year, t.monthValue - 1, t.dayOfMonth).show()
}

// Pomodoro: 25 dk çalışma + 5 dk mola. Mola süresi çalışmaya sayılmaz.
fun breakSeconds(elapsed: Int): Int = (elapsed / 1800) * 300 + maxOf(0, elapsed % 1800 - 1500)

@Composable
fun StudyScreen(prefs: Prefs, data: Data, clock: Clock) {
    val exam = prefs.exam ?: Exam.LGS
    val ctx = LocalContext.current
    val view = LocalView.current
    val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    val subjects = subjectsFor(exam)
    var subject by remember(exam) { mutableStateOf(clock.label.takeIf { it in subjects } ?: subjects.first()) }
    val pomodoro = clock.pomodoro
    var focus by remember { mutableStateOf(false) }
    var showDate by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val running = clock.running
    val elapsed = clock.elapsed()
    val studied = elapsed - (if (pomodoro) breakSeconds(elapsed) else 0)
    val hide = focus && running

    DisposableEffect(focus && running) {
        view.keepScreenOn = focus && running
        var prev = -1
        if (focus && running && nm.isNotificationPolicyAccessGranted) {
            prev = nm.currentInterruptionFilter
            nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_NONE)
        }
        onDispose {
            view.keepScreenOn = false
            if (prev != -1 && nm.isNotificationPolicyAccessGranted) nm.setInterruptionFilter(prev)
        }
    }

    val today = LocalDate.now()
    val weekStart = today.minusDays(6)
    val todaySec = data.sessions.filter { it.day == today.toString() }.sumOf { it.seconds }
    val week = data.sessions.filter {
        runCatching { val d = LocalDate.parse(it.day); !d.isBefore(weekStart) && !d.isAfter(today) }.getOrDefault(false)
    }
    val weekSec = week.sumOf { it.seconds }

    if (showDate) {
        AlertDialog(
            onDismissRequest = { showDate = false },
            title = { Text("${exam.label} tarihi") },
            text = { Text("Tarih internetten otomatik alınır. İnternet yoksa ya da farklı bir tarih istersen elle seçebilirsin.") },
            confirmButton = {
                TextButton(onClick = { showDate = false; pickDate(ctx) { data.chooseExamDate(exam, it) } }) { Text("Elle seç") }
            },
            dismissButton = {
                TextButton(onClick = { showDate = false; data.useAuto(exam); scope.launch { data.syncOnline() } }) { Text("Otomatik") }
            }
        )
    }

    Column(Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(24.dp)) {
        if (!hide) {
            val iso = data.examDates[exam.name]
            Surface(
                onClick = { showDate = true },
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(18.dp)) {
                    if (iso == null) {
                        Text("${exam.label} tarihini seç", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                        Text(if (data.syncState == 2) "İnternet yok. Dokunup tarihi elle seç" else "Dokun", color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f))
                    } else {
                        val d = daysUntil(iso)
                        Text(if (d >= 0) "$d gün" else "Sınav geçti", fontSize = 32.sp, fontWeight = FontWeight.Bold)
                        Text("${exam.label} · ${fmtDate(iso)} · " + (if (data.modes[exam.name] == "manual") "elle seçildi" else when (data.syncState) { 1 -> "internetten"; 2 -> "çevrimdışı, kayıtlı tarih"; else -> "kontrol ediliyor" }), color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f))
                    }
                }
            }
            Spacer(Modifier.height(20.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                subjects.forEach { s ->
                    FilterChip(selected = subject == s, onClick = { subject = s },
                        enabled = !running && clock.accum == 0, label = { Text(s) })
                }
            }
        } else {
            Text(subject, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        }

        Spacer(Modifier.height(24.dp))
        Text(fmtClock(studied), fontSize = 68.sp, fontWeight = FontWeight.Bold)
        if (pomodoro) {
            val c = elapsed % 1800
            Text(if (c < 1500) "Çalışma · ${fmtClock(1500 - c)}" else "Mola · ${fmtClock(1800 - c)}",
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
        }
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(onClick = { if (running) clock.pause() else clock.start(subject) }) {
                Text(if (running) "Duraklat" else if (elapsed > 0) "Devam" else "Başlat")
            }
            OutlinedButton(
                enabled = elapsed > 0,
                onClick = {
                    if (studied > 0) data.addSession(subject, studied)
                    clock.reset()
                }
            ) { Text("Bitir ve kaydet") }
        }

        Spacer(Modifier.height(20.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Pomodoro (25 dk / 5 dk)", Modifier.weight(1f))
            Switch(checked = pomodoro, onCheckedChange = { clock.usePomodoro(it) }, enabled = !running && clock.accum == 0)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Odak modu", Modifier.weight(1f))
            Switch(checked = focus, onCheckedChange = { focus = it })
        }
        if (focus && !nm.isNotificationPolicyAccessGranted) {
            TextButton(onClick = {
                ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
            }) { Text("Rahatsız etme iznini ver") }
        }

        if (!hide) {
            Spacer(Modifier.height(24.dp))
            Text("Bugün: ${fmtDur(todaySec)}", fontWeight = FontWeight.SemiBold)
            Text("Son 7 gün: ${fmtDur(weekSec)}", fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            week.groupBy { it.subject }.forEach { (s, list) ->
                Text("$s · ${fmtDur(list.sumOf { it.seconds })}",
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f))
            }
        }
    }
}

@Composable
fun TodoScreen(data: Data) {
    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .padding(24.dp)
    ) {
        SchedulePane(data)
    }
}

@Composable
fun TestScreen(prefs: Prefs, data: Data, clock: Clock) {
    var page by remember { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize().statusBarsPadding().padding(24.dp)) {
        Text("Deneme", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = page == 0, onClick = { page = 0 }, label = { Text("Sınav modu") })
            FilterChip(selected = page == 1, onClick = { page = 1 }, label = { Text("Takvim") })
        }
        Spacer(Modifier.height(20.dp))
        if (page == 0) ExamMode(prefs, clock) else CalendarPane(data)
    }
}

@Composable
fun ExamMode(prefs: Prefs, clock: Clock) {
    val exam = prefs.exam ?: Exam.LGS
    val presets = if (exam == Exam.LGS) listOf("Sözel" to 75, "Sayısal" to 80) else listOf("TYT" to 165, "AYT" to 180)
    var sel by remember(exam) { mutableIntStateOf(0) }
    val total = presets[sel].second * 60
    val remaining = total - clock.elapsed()
    val view = LocalView.current

    LaunchedEffect(remaining <= 0, clock.running) {
        if (remaining <= 0 && clock.running) { clock.finishAt(total) }
    }
    DisposableEffect(clock.running) {
        view.keepScreenOn = clock.running
        onDispose { view.keepScreenOn = false }
    }

    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        presets.forEachIndexed { i, p ->
            FilterChip(selected = sel == i, onClick = { sel = i }, enabled = clock.elapsed() == 0,
                label = { Text("${p.first} · ${p.second} dk") })
        }
    }
    Spacer(Modifier.height(24.dp))
    Text(fmtClock(remaining), fontSize = 68.sp, fontWeight = FontWeight.Bold)
    Text(if (remaining <= 0) "Süre bitti" else "Kalan süre",
        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f))
    Spacer(Modifier.height(16.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Button(enabled = remaining > 0, onClick = { if (clock.running) clock.pause() else clock.start() }) {
            Text(if (clock.running) "Duraklat" else if (clock.elapsed() > 0) "Devam" else "Başlat")
        }
        OutlinedButton(enabled = clock.elapsed() > 0, onClick = { clock.reset() }) { Text("Sıfırla") }
    }
}

@Composable
fun CalendarPane(data: Data) {
    val ctx = LocalContext.current
    var title by remember { mutableStateOf("") }
    var day by remember { mutableStateOf(LocalDate.now().toString()) }
    OutlinedTextField(
        value = title, onValueChange = { title = it }, singleLine = true,
        placeholder = { Text("Deneme, sınav veya ödev adı") }, modifier = Modifier.fillMaxWidth()
    )
    Spacer(Modifier.height(8.dp))
    Row(verticalAlignment = Alignment.CenterVertically) {
        OutlinedButton(onClick = { pickDate(ctx) { day = it } }) { Text(fmtDate(day)) }
        Spacer(Modifier.width(8.dp))
        Button(onClick = {
            if (title.isNotBlank()) { data.addEvent(title.trim(), day); title = "" }
        }) { Text("Ekle") }
    }
    Spacer(Modifier.height(12.dp))
    LazyColumn(Modifier.fillMaxWidth()) {
        items(data.events.sortedBy { it.day }, key = { it.id }) { e ->
            val d = runCatching { daysUntil(e.day) }.getOrDefault(0L)
            val rel = when {
                d == 0L -> "bugün"
                d > 0L -> "$d gün sonra"
                else -> "geçti"
            }
            Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(e.title, fontWeight = FontWeight.SemiBold)
                    Text("${fmtDate(e.day)} · $rel", color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.65f))
                }
                IconButton(onClick = { data.removeEvent(e.id) }) {
                    Icon(Icons.Filled.Close, contentDescription = "Sil")
                }
            }
        }
    }
}
