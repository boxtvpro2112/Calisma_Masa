package com.example.calisma

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import org.json.JSONArray
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.temporal.TemporalAdjusters
import java.time.ZoneId
import java.time.temporal.ChronoUnit

object Notifs {
    const val TIMER = "timer"
    const val REMIND = "reminders"
    private const val TIMER_ID = 1001

    private fun nm(ctx: Context) = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    fun ensureChannels(ctx: Context) {
        nm(ctx).createNotificationChannel(NotificationChannel(TIMER, "Çalışma sayacı", NotificationManager.IMPORTANCE_LOW))
        nm(ctx).createNotificationChannel(NotificationChannel(REMIND, "Hatırlatmalar", NotificationManager.IMPORTANCE_DEFAULT))
    }

    fun openApp(ctx: Context): PendingIntent = PendingIntent.getActivity(
        ctx, 0,
        Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    fun timer(ctx: Context, running: Boolean, label: String, startedAt: Long, accumSec: Int) {
        if (!running) { nm(ctx).cancel(TIMER_ID); return }
        ensureChannels(ctx)
        val n = Notification.Builder(ctx, TIMER)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("Çalışıyor")
            .setContentText(label)
            .setWhen(startedAt - accumSec * 1000L)
            .setUsesChronometer(true)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openApp(ctx))
            .build()
        nm(ctx).notify(TIMER_ID, n)
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        Notifs.ensureChannels(ctx)
        val title = intent.getStringExtra("title") ?: return
        val text = intent.getStringExtra("text") ?: ""
        val n = Notification.Builder(ctx, Notifs.REMIND)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle(title)
            .setContentText(text)
            .setAutoCancel(true)
            .setContentIntent(Notifs.openApp(ctx))
            .build()
        (ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
            .notify(intent.getIntExtra("nid", 0), n)
        val bid = intent.getLongExtra("block", 0L)
        if (bid != 0L) Reminders.rescheduleBlock(ctx, bid)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) Reminders.rescheduleFromPrefs(ctx)
    }
}

object Reminders {
    private fun code(id: Long, k: Int): Int = (id % 1_000_000L).toInt() * 2 + k

    private fun pending(ctx: Context, code: Int, title: String, text: String): PendingIntent {
        val i = Intent(ctx, ReminderReceiver::class.java)
            .putExtra("title", title).putExtra("text", text).putExtra("nid", code)
        return PendingIntent.getBroadcast(ctx, code, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    fun schedule(ctx: Context, e: Event) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val d = runCatching { LocalDate.parse(e.day) }.getOrNull() ?: return
        val zone = ZoneId.systemDefault()
        val now = System.currentTimeMillis()
        val t1 = d.minusDays(1).atTime(9, 0).atZone(zone).toInstant().toEpochMilli()
        val t2 = d.atTime(8, 0).atZone(zone).toInstant().toEpochMilli()
        if (t1 > now) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t1, pending(ctx, code(e.id, 0), "Yarın: ${e.title}", fmtDate(e.day)))
        if (t2 > now) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t2, pending(ctx, code(e.id, 1), "Bugün: ${e.title}", "Başarılar!"))
    }

    fun cancel(ctx: Context, id: Long) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pending(ctx, code(id, 0), "", ""))
        am.cancel(pending(ctx, code(id, 1), "", ""))
    }

    private fun blockCode(id: Long): Int = 3_000_000 + (id % 1_000_000L).toInt()

    private fun pendingBlock(ctx: Context, id: Long, title: String, text: String): PendingIntent {
        val c = blockCode(id)
        val i = Intent(ctx, ReminderReceiver::class.java)
            .putExtra("title", title).putExtra("text", text).putExtra("nid", c).putExtra("block", id)
        return PendingIntent.getBroadcast(ctx, c, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    /** Haftalık tekrar: bir sonraki bloğun başlangıç saatine kurar, tetiklenince bir sonraki haftaya yeniden kurulur. */
    fun scheduleBlock(ctx: Context, b: Block) {
        if (!b.remind) return
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val zone = ZoneId.systemDefault()
        val now = System.currentTimeMillis()
        var dt = LocalDate.now().with(TemporalAdjusters.nextOrSame(DayOfWeek.of(b.day))).atTime(b.start / 60, b.start % 60)
        while (dt.atZone(zone).toInstant().toEpochMilli() <= now) dt = dt.plusWeeks(1)
        am.setAndAllowWhileIdle(
            AlarmManager.RTC_WAKEUP, dt.atZone(zone).toInstant().toEpochMilli(),
            pendingBlock(ctx, b.id, b.title, "Şimdi: ${fmtTime(b.start)}–${fmtTime(b.end)}")
        )
    }

    fun cancelBlock(ctx: Context, id: Long) {
        (ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pendingBlock(ctx, id, "", ""))
    }

    private fun loadBlocks(ctx: Context): List<Block> = runCatching {
        val a = JSONArray(ctx.getSharedPreferences("calisma_data", Context.MODE_PRIVATE).getString("blocks", "[]"))
        (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            Block(o.getLong("i"), o.getInt("d"), o.getInt("s"), o.getInt("e"),
                o.getString("t"), o.getBoolean("r"), o.optString("w", ""), o.optString("c", ""))
        }
    }.getOrDefault(emptyList())

    fun rescheduleBlock(ctx: Context, id: Long) {
        loadBlocks(ctx).firstOrNull { it.id == id }?.let { scheduleBlock(ctx, it) }
    }

    fun rescheduleFromPrefs(ctx: Context) {
        loadBlocks(ctx).forEach { scheduleBlock(ctx, it) }
        runCatching {
            val sp = ctx.getSharedPreferences("calisma_data", Context.MODE_PRIVATE)
            val a = JSONArray(sp.getString("events", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                schedule(ctx, Event(o.getLong("i"), o.getString("t"), o.getString("d")))
            }
        }
    }
}

class CountdownWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { manager.updateAppWidget(it, build(context)) }
    }

    companion object {
        fun refresh(ctx: Context) {
            val m = AppWidgetManager.getInstance(ctx)
            val ids = m.getAppWidgetIds(ComponentName(ctx, CountdownWidget::class.java))
            ids.forEach { m.updateAppWidget(it, build(ctx)) }
        }

        private fun build(ctx: Context): RemoteViews {
            val v = RemoteViews(ctx.packageName, R.layout.widget_countdown)
            val exam = ctx.getSharedPreferences("calisma", Context.MODE_PRIVATE).getString("exam", null)
            val iso = exam?.let { ctx.getSharedPreferences("calisma_data", Context.MODE_PRIVATE).getString("date_$it", null) }
            val days: Long? = iso?.let { runCatching { ChronoUnit.DAYS.between(LocalDate.now(), LocalDate.parse(it)) }.getOrNull() }
            v.setTextViewText(R.id.w_label, exam ?: "Çalışma Masası")
            v.setTextViewText(R.id.w_num, when {
                exam == null -> "–"
                days == null -> "?"
                days < 0 -> "0"
                else -> days.toString()
            })
            v.setTextViewText(R.id.w_unit, when {
                exam == null -> "Uygulamayı aç"
                days == null -> "Tarih seç"
                days < 0 -> "Sınav geçti"
                else -> "gün kaldı"
            })
            v.setOnClickPendingIntent(R.id.w_root, Notifs.openApp(ctx))
            return v
        }
    }
}
