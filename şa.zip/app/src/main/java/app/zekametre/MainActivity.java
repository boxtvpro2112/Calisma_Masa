package app.zekametre;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {

    private static final String HOME = "https://zekametre.vercel.app/";
    private static final String HOST = "zekametre.vercel.app";

    private static final String OFFLINE_HTML =
        "<html><head><meta charset='utf-8'>"
        + "<meta name='viewport' content='width=device-width, initial-scale=1'></head>"
        + "<body style='font-family:sans-serif;background:#f7f8fc;color:#1b1d2a;"
        + "display:flex;flex-direction:column;align-items:center;justify-content:center;"
        + "height:100vh;margin:0;text-align:center;padding:24px'>"
        + "<h2>Baglanti kurulamadi</h2>"
        + "<p>Internet baglantini kontrol edip tekrar dene.</p>"
        + "<a href='" + HOME + "' style='background:#5b5bd6;color:#fff;"
        + "padding:12px 24px;border-radius:12px;text-decoration:none'>Tekrar dene</a>"
        + "</body></html>";

    private WebView web;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().setStatusBarColor(Color.parseColor("#F7F8FC"));
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);

        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        android.webkit.CookieManager.getInstance().setAcceptCookie(true);
        android.webkit.CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return false;
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) {
                    view.loadDataWithBaseURL(null, OFFLINE_HTML, "text/html", "UTF-8", null);
                }
            }
        });

        if (savedInstanceState == null) {
            web.loadUrl(HOME);
        } else {
            web.restoreState(savedInstanceState);
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        web.saveState(outState);
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) {
            web.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
