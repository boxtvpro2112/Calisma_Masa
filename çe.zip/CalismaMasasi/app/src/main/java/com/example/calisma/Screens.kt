package com.example.calisma

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import android.content.Context
import androidx.compose.ui.platform.LocalContext

@Composable
fun ExamPicker(prefs: Prefs) {
    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)
            .systemBarsPadding().padding(28.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text("Hangi sınava hazırlanıyorsun?", fontSize = 30.sp, fontWeight = FontWeight.Bold,
            lineHeight = 36.sp, color = MaterialTheme.colorScheme.onBackground)
        Spacer(Modifier.height(8.dp))
        Text("Ders listesi buna göre gelir. Sonra ayarlardan değiştirebilirsin.",
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f))
        Spacer(Modifier.height(28.dp))
        Exam.values().forEach { e ->
            Surface(
                onClick = { prefs.chooseExam(e) },
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.fillMaxWidth().padding(bottom = 14.dp)
            ) {
                Column(Modifier.padding(22.dp)) {
                    Text(e.label, fontSize = 24.sp, fontWeight = FontWeight.SemiBold)
                    Text(if (e == Exam.LGS) "8. sınıf, ortaokul" else "TYT ve AYT, lise",
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f))
                }
            }
        }
    }
}

private enum class Tab(val label: String, val icon: ImageVector) {
    STUDY("Çalışma", Icons.Filled.Home),
    TODO("Yapılacaklar", Icons.Filled.Check),
    TEST("Deneme", Icons.Filled.Star),
    NOTES("Defter", Icons.Filled.Edit),
    SETTINGS("Ayarlar", Icons.Filled.Settings)
}

@Composable
fun MainShell(prefs: Prefs, data: Data) {
    var tab by remember { mutableStateOf(Tab.STUDY) }
    val ctx = LocalContext.current
    val studyClock = remember { Clock(ctx.getSharedPreferences("clock", Context.MODE_PRIVATE), "study") }
    val examClock = remember { Clock(ctx.getSharedPreferences("clock", Context.MODE_PRIVATE), "exam") }
    LaunchedEffect(studyClock.running, studyClock.label) {
        Notifs.timer(ctx, studyClock.running, studyClock.label, studyClock.startedAt, studyClock.accum)
    }
    LaunchedEffect(studyClock.running, examClock.running) {
        while (studyClock.running || examClock.running) {
            val n = System.currentTimeMillis()
            studyClock.now = n
            examClock.now = n
            delay(500)
        }
    }
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar {
                Tab.values().forEach { t ->
                    NavigationBarItem(
                        selected = tab == t, onClick = { tab = t },
                        icon = { Icon(t.icon, contentDescription = t.label) },
                        label = { Text(t.label, fontSize = 11.sp) }
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                Tab.SETTINGS -> SettingsScreen(prefs)
                Tab.STUDY -> StudyScreen(prefs, data, studyClock)
                Tab.TODO -> TodoScreen(data)
                Tab.TEST -> TestScreen(prefs, data, examClock)
                Tab.NOTES -> NotebookScreen(prefs, data)
            }
        }
    }
}

@Composable
fun Placeholder(title: String) {
    Column(Modifier.fillMaxSize().statusBarsPadding().padding(24.dp)) {
        Text(title, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("Bu ekran sonraki adımda eklenecek.",
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.65f))
    }
}

@Composable
fun SettingsScreen(prefs: Prefs) {
    Column(Modifier.fillMaxSize().statusBarsPadding().padding(24.dp)) {
        Text("Ayarlar", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(24.dp))

        Text("Sınav", fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Exam.values().forEach { e ->
                FilterChip(selected = prefs.exam == e, onClick = { prefs.chooseExam(e) }, label = { Text(e.label) })
            }
        }

        Spacer(Modifier.height(24.dp))
        Text("Tema", fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Mode.values().forEach { m ->
                FilterChip(selected = prefs.mode == m, onClick = { prefs.chooseMode(m) }, label = { Text(m.label) })
            }
        }

        Spacer(Modifier.height(24.dp))
        Text("Renk", fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Accents.forEachIndexed { i, a ->
                val selected = prefs.accent == i
                Box(
                    Modifier.size(44.dp).clip(CircleShape).background(a.light)
                        .then(if (selected) Modifier.background(a.light) else Modifier)
                        .clickable { prefs.chooseAccent(i) },
                    contentAlignment = Alignment.Center
                ) {
                    if (selected) Icon(Icons.Filled.Check, contentDescription = a.name, tint = androidx.compose.ui.graphics.Color.White)
                }
            }
        }
    }
}
