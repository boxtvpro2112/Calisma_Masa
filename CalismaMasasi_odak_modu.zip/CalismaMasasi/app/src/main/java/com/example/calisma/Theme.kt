package com.example.calisma

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

class AccentColor(val name: String, val light: Color, val dark: Color)

val Accents = listOf(
    AccentColor("Mavi", Color(0xFF2F5BEA), Color(0xFF9DB4FF)),
    AccentColor("Yeşil", Color(0xFF1E8E5A), Color(0xFF8FDDB5)),
    AccentColor("Mor", Color(0xFF7B4FD6), Color(0xFFCBB2FF)),
    AccentColor("Turuncu", Color(0xFFC25A12), Color(0xFFFFB98A)),
)

@Composable
fun AppTheme(prefs: Prefs, content: @Composable () -> Unit) {
    val dark = when (prefs.mode) {
        Mode.SYSTEM -> isSystemInDarkTheme()
        Mode.LIGHT -> false
        Mode.DARK -> true
    }
    val a = Accents[prefs.accent]
    val scheme = if (dark) darkColorScheme(
        primary = a.dark, onPrimary = Color(0xFF101114),
        background = Color(0xFF111215), surface = Color(0xFF111215),
        surfaceVariant = Color(0xFF1E2025), onBackground = Color(0xFFE8E9EC), onSurface = Color(0xFFE8E9EC)
    ) else lightColorScheme(
        primary = a.light, onPrimary = Color.White,
        background = Color(0xFFF7F8FA), surface = Color(0xFFF7F8FA),
        surfaceVariant = Color(0xFFE9ECF1), onBackground = Color(0xFF15171B), onSurface = Color(0xFF15171B)
    )
    MaterialTheme(colorScheme = scheme, content = content)
}
