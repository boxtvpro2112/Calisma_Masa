package com.example.calisma

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.ImageBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.util.Locale

private class AppItem(val pkg: String, val label: String, val icon: ImageBitmap?, val isGame: Boolean)

private val Suggested = listOf(
    "Instagram" to "com.instagram.android",
    "TikTok" to "com.zhiliaoapp.musically",
    "TikTok " to "com.ss.android.ugc.trill",
    "YouTube" to "com.google.android.youtube",
    "X" to "com.twitter.android",
    "Snapchat" to "com.snapchat.android",
    "Facebook" to "com.facebook.katana"
)

private fun Drawable.toSmallBitmap(px: Int = 96): Bitmap {
    val bmp = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
    val c = Canvas(bmp)
    setBounds(0, 0, px, px)
    draw(c)
    return bmp
}

private fun loadApps(ctx: Context): List<AppItem> {
    val pm = ctx.packageManager
    val launch = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    val infos = if (Build.VERSION.SDK_INT >= 33)
        pm.queryIntentActivities(launch, PackageManager.ResolveInfoFlags.of(0))
    else @Suppress("DEPRECATION") pm.queryIntentActivities(launch, 0)
    return infos.map { it.activityInfo.applicationInfo }
        .filter { it.packageName != ctx.packageName }
        .distinctBy { it.packageName }
        .map { ai ->
            @Suppress("DEPRECATION")
            val game = Build.VERSION.SDK_INT >= 26 && ai.category == ApplicationInfo.CATEGORY_GAME ||
                (ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0
            AppItem(
                ai.packageName,
                pm.getApplicationLabel(ai).toString(),
                runCatching { pm.getApplicationIcon(ai).toSmallBitmap().asImageBitmap() }.getOrNull(),
                game
            )
        }
        .sortedBy { it.label.lowercase(Locale("tr")) }
}

/**
 * Konsantrasyon ayarları: engellenecek uygulamaları seçme + gerekli izinler.
 * Odak modu ilk kez açıldığında doğrudan bu ekran gelir.
 */
@Composable
fun FocusSettingsScreen(prefs: Prefs, onClose: () -> Unit) {
    val ctx = LocalContext.current
    BackHandler { onClose() }

    var apps by remember { mutableStateOf<List<AppItem>?>(null) }
    var selected by remember { mutableStateOf(prefs.blocked) }
    var query by remember { mutableStateOf("") }
    var usage by remember { mutableStateOf(FocusPerms.hasUsage(ctx)) }
    var overlay by remember { mutableStateOf(FocusPerms.hasOverlay(ctx)) }
    var notif by remember { mutableStateOf(FocusPerms.hasNotif(ctx)) }

    LaunchedEffect(Unit) { apps = withContext(Dispatchers.Default) { loadApps(ctx) } }
    // Kullanıcı sistem ayarından dönünce durumlar güncellensin.
    LaunchedEffect(Unit) {
        while (true) {
            usage = FocusPerms.hasUsage(ctx)
            overlay = FocusPerms.hasOverlay(ctx)
            notif = FocusPerms.hasNotif(ctx)
            delay(700)
        }
    }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        notif = ok
        if (!ok) FocusPerms.open(ctx, FocusPerms.notifSettingsIntent(ctx))
    }

    val allPerms = usage && overlay && notif
    val canSave = allPerms && selected.isNotEmpty()
    val list = apps

    Column(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 24.dp, vertical = 16.dp)) {
        Text("Konsantrasyon ayarları", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        Text("Odak modu açıkken seçtiğin uygulamalar açılamaz; seni Çalışma Masası'na geri getirir.",
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f))

        LazyColumn(Modifier.weight(1f)) {
            item {
                Spacer(Modifier.height(16.dp))
                Text("1. İzinler", fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                PermRow("Kullanım erişimi", "Hangi uygulamanın açık olduğunu görmek için.", usage) {
                    FocusPerms.open(ctx, FocusPerms.usageIntent(ctx), Intent(android.provider.Settings.ACTION_USAGE_ACCESS_SETTINGS))
                }
                PermRow("Diğer uygulamaların üzerinde göster", "Engellenen uygulama açılınca Çalışma Masası'nı öne getirmek için.", overlay) {
                    FocusPerms.open(ctx, FocusPerms.overlayIntent(ctx), Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION))
                }
                PermRow("Bildirim", "Odak modu açıkken görünen sabit bildirim için.", notif) {
                    if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
                    else FocusPerms.open(ctx, FocusPerms.notifSettingsIntent(ctx))
                }
                Spacer(Modifier.height(20.dp))
                Text("2. Engellenecek uygulamalar", fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                if (list != null) {
                    val sug = Suggested.filter { s -> list.any { it.pkg == s.second } }
                    val hasGames = list.any { it.isGame }
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        sug.forEach { (name, pkg) ->
                            FilterChip(selected = pkg in selected, label = { Text(name.trim()) },
                                onClick = { selected = if (pkg in selected) selected - pkg else selected + pkg })
                        }
                        if (hasGames) {
                            val gamePkgs = list.filter { it.isGame }.map { it.pkg }.toSet()
                            val allGames = selected.containsAll(gamePkgs)
                            FilterChip(selected = allGames, label = { Text("Tüm oyunlar") },
                                onClick = { selected = if (allGames) selected - gamePkgs else selected + gamePkgs })
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                }
                OutlinedTextField(
                    value = query, onValueChange = { query = it }, singleLine = true,
                    placeholder = { Text("Uygulama ara") }, modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(4.dp))
            }
            if (list == null) {
                item { Text("Uygulamalar yükleniyor…", Modifier.padding(vertical = 12.dp)) }
            } else {
                val shown = list.filter { it.label.contains(query.trim(), ignoreCase = true) }
                items(shown, key = { it.pkg }) { a ->
                    val on = a.pkg in selected
                    Row(
                        Modifier.fillMaxWidth()
                            .clickable { selected = if (on) selected - a.pkg else selected + a.pkg }
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (a.icon != null) Image(a.icon, null, Modifier.size(36.dp))
                        else Spacer(Modifier.size(36.dp))
                        Spacer(Modifier.width(12.dp))
                        Text(a.label, Modifier.weight(1f))
                        Checkbox(checked = on, onCheckedChange = { selected = if (on) selected - a.pkg else selected + a.pkg })
                    }
                }
            }
        }

        Spacer(Modifier.height(8.dp))
        if (!allPerms) Text("Odak modunu açmak için üç iznin de verilmesi gerekir.",
            color = MaterialTheme.colorScheme.error, fontSize = 13.sp)
        else if (selected.isEmpty()) Text("En az bir uygulama seç.",
            color = MaterialTheme.colorScheme.error, fontSize = 13.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.padding(top = 4.dp)) {
            OutlinedButton(onClick = onClose) { Text("Vazgeç") }
            Button(enabled = canSave, onClick = {
                prefs.saveBlocked(selected)
                prefs.markFocusConfigured()
                prefs.setFocus(true)
                onClose()
            }) { Text("Kaydet ve odak modunu aç") }
        }
    }
}

@Composable
private fun PermRow(title: String, desc: String, granted: Boolean, onGrant: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.SemiBold)
                Text(desc, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
            }
            Spacer(Modifier.width(8.dp))
            if (granted) Icon(Icons.Filled.Check, contentDescription = "Verildi", tint = MaterialTheme.colorScheme.primary)
            else Button(onClick = onGrant) { Text("İzin ver") }
        }
    }
}
