package com.example.calisma

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.text.StaticLayout
import android.text.TextPaint
import android.widget.Toast
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import android.media.ExifInterface
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.FileProvider

fun loadBitmap(path: String, maxSize: Int): Bitmap? {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(path, bounds)
    if (bounds.outWidth <= 0) return null
    var sample = 1
    while (bounds.outWidth / sample > maxSize * 2 || bounds.outHeight / sample > maxSize * 2) sample *= 2
    val opts = BitmapFactory.Options().apply { inSampleSize = sample }
    val bmp = BitmapFactory.decodeFile(path, opts) ?: return null
    val rot = when (runCatching {
        ExifInterface(path).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)
    }.getOrDefault(1)) {
        6 -> 90f
        3 -> 180f
        8 -> 270f
        else -> 0f
    }
    return if (rot == 0f) bmp
    else Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(rot) }, true)
}

@Composable
fun NotebookScreen(prefs: Prefs, data: Data) {
    val exam = prefs.exam ?: Exam.LGS
    val ctx: Context = LocalContext.current
    val subjects = subjectsFor(exam)
    var filter by remember(exam) { mutableStateOf<String?>(null) }
    var query by remember { mutableStateOf("") }
    var pendingId by rememberSaveable { mutableStateOf<Long?>(null) }
    var cameraId by rememberSaveable { mutableStateOf<Long?>(null) }
    var viewingId by remember { mutableStateOf<Long?>(null) }
    var status by remember { mutableIntStateOf(0) }
    val viewing = data.questions.firstOrNull { it.id == viewingId }
    val scope = rememberCoroutineScope()

    val gallery = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val id = System.currentTimeMillis()
            val ok = runCatching {
                ctx.contentResolver.openInputStream(uri)!!.use { input ->
                    data.imageFile(id).outputStream().use { out -> input.copyTo(out) }
                }
            }.isSuccess
            if (ok) pendingId = id
        }
    }
    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val id = cameraId
        if (id != null) {
            if (ok) pendingId = id else data.imageFile(id).delete()
        }
        cameraId = null
    }

    val list = data.questions
        .filter { (filter == null || it.subject == filter) && (query.isBlank() || it.note.contains(query, ignoreCase = true)) &&
            (status == 0 || (status == 1 && !it.solved) || (status == 2 && it.solved)) }
        .sortedByDescending { it.id }

    val pdf = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if (uri != null) {
            val items = list
            scope.launch {
                val ok = withContext(Dispatchers.IO) { runCatching { exportPdf(ctx, data, items, uri) }.isSuccess }
                Toast.makeText(ctx, if (ok) "PDF kaydedildi" else "PDF oluşturulamadı", Toast.LENGTH_SHORT).show()
            }
        }
    }

    Column(Modifier.fillMaxSize().statusBarsPadding().padding(24.dp)) {
        Text("Soru Defteri", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = { gallery.launch("image/*") }) { Text("Galeri") }
            Button(onClick = {
                val id = System.currentTimeMillis()
                val f = data.imageFile(id)
                runCatching { f.createNewFile() }
                cameraId = id
                camera.launch(FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", f))
            }) { Text("Kamera") }
            OutlinedButton(enabled = list.isNotEmpty(), onClick = { pdf.launch("soru-defteri.pdf") }) { Text("PDF") }
        }
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = query, onValueChange = { query = it }, singleLine = true,
            placeholder = { Text("Notlarda ara") }, modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = filter == null, onClick = { filter = null }, label = { Text("Tümü") })
            subjects.forEach { s ->
                FilterChip(selected = filter == s, onClick = { filter = s }, label = { Text(s) })
            }
        }
        Spacer(Modifier.height(4.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Hepsi", "Çözülmedi", "Çözüldü").forEachIndexed { i, label ->
                FilterChip(selected = status == i, onClick = { status = i }, label = { Text(label) })
            }
        }
        Spacer(Modifier.height(12.dp))
        if (list.isEmpty()) {
            Text(
                if (data.questions.isEmpty()) "Henüz soru yok. Çözemediğin bir soruyu ekle." else "Sonuç yok.",
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
            )
        }
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(list, key = { it.id }) { q ->
                val bmp = remember(q.id) { loadBitmap(data.imageFile(q.id).path, 500) }
                Surface(
                    onClick = { viewingId = q.id },
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant
                ) {
                    Column {
                        if (bmp != null) {
                            Image(
                                bitmap = bmp.asImageBitmap(), contentDescription = q.subject,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxWidth().height(140.dp)
                            )
                        }
                        Column(Modifier.padding(10.dp)) {
                            Text(q.subject, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            if (q.solved) Text("✓ Çözüldü", fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                            if (q.note.isNotBlank()) {
                                Text(q.note, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
                            }
                        }
                    }
                }
            }
        }
    }

    pendingId?.let { id ->
        var subj by remember(id) { mutableStateOf(subjects.first()) }
        var note by remember(id) { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { data.imageFile(id).delete(); pendingId = null },
            title = { Text("Soruyu kaydet") },
            text = {
                Column {
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        subjects.forEach { s ->
                            FilterChip(selected = subj == s, onClick = { subj = s }, label = { Text(s) })
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(
                        value = note, onValueChange = { note = it }, minLines = 2,
                        placeholder = { Text("Not (konu, neden yanlış yaptım...)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { data.addQuestion(id, subj, note.trim()); pendingId = null }) { Text("Kaydet") }
            },
            dismissButton = {
                TextButton(onClick = { data.imageFile(id).delete(); pendingId = null }) { Text("İptal") }
            }
        )
    }

    viewing?.let { q ->
        var scale by remember(q.id) { mutableFloatStateOf(1f) }
        var offset by remember(q.id) { mutableStateOf(Offset.Zero) }
        var confirm by remember(q.id) { mutableStateOf(false) }
        val bmp = remember(q.id) { loadBitmap(data.imageFile(q.id).path, 2000) }
        Dialog(onDismissRequest = { viewingId = null }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
            Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                Column(Modifier.statusBarsPadding().navigationBarsPadding().padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("${q.subject} · ${fmtDate(q.day)}", Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                        TextButton(onClick = { viewingId = null }) { Text("Kapat") }
                    }
                    if (bmp != null) {
                        Image(
                            bitmap = bmp.asImageBitmap(), contentDescription = q.subject,
                            contentScale = ContentScale.Fit,
                            modifier = Modifier.weight(1f).fillMaxWidth().clipToBounds()
                                .pointerInput(q.id) {
                                    detectTransformGestures { _, pan, zoom, _ ->
                                        scale = (scale * zoom).coerceIn(1f, 5f)
                                        offset = if (scale == 1f) Offset.Zero else offset + pan
                                    }
                                }
                                .graphicsLayer(scaleX = scale, scaleY = scale, translationX = offset.x, translationY = offset.y)
                        )
                    } else {
                        Spacer(Modifier.weight(1f))
                    }
                    if (q.note.isNotBlank()) {
                        Spacer(Modifier.height(8.dp))
                        Text(q.note)
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        TextButton(onClick = { data.toggleSolved(q.id) }) {
                            Text(if (q.solved) "Çözülmedi yap" else "Çözüldü işaretle")
                        }
                        TextButton(onClick = {
                            if (confirm) { data.removeQuestion(q.id); viewingId = null } else confirm = true
                        }) { Text(if (confirm) "Silmek için tekrar dokun" else "Sil") }
                    }
                }
            }
        }
    }
}

fun exportPdf(ctx: Context, data: Data, list: List<Question>, uri: Uri) {
    val doc = PdfDocument()
    val paint = Paint(Paint.FILTER_BITMAP_FLAG)
    val tp = TextPaint().apply { isAntiAlias = true; color = android.graphics.Color.BLACK }
    list.forEachIndexed { i, q ->
        val page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, i + 1).create())
        val c = page.canvas
        tp.textSize = 16f; tp.isFakeBoldText = true
        c.drawText("${q.subject} · ${fmtDate(q.day)}${if (q.solved) " · Çözüldü" else ""}", 40f, 50f, tp)
        tp.textSize = 13f; tp.isFakeBoldText = false
        var y = 70f
        val bmp = loadBitmap(data.imageFile(q.id).path, 1600)
        if (bmp != null) {
            val sc = minOf(515f / bmp.width, 640f / bmp.height)
            val w = bmp.width * sc; val h = bmp.height * sc
            c.drawBitmap(bmp, null, RectF(40f, y, 40f + w, y + h), paint)
            y += h + 20f
        }
        if (q.note.isNotBlank()) {
            c.save(); c.translate(40f, y)
            StaticLayout.Builder.obtain(q.note, 0, q.note.length, tp, 515).build().draw(c)
            c.restore()
        }
        doc.finishPage(page)
    }
    ctx.contentResolver.openOutputStream(uri)?.use { doc.writeTo(it) }
    doc.close()
}
