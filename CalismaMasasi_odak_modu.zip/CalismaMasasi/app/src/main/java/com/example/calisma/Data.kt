package com.example.calisma

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import androidx.compose.runtime.mutableStateMapOf
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.temporal.TemporalAdjusters

data class Session(val subject: String, val seconds: Int, val day: String)
data class Task(val id: Long, val text: String, val done: Boolean)
data class Event(val id: Long, val title: String, val day: String)
data class Block(
    val id: Long, val day: Int, val start: Int, val end: Int,
    val title: String, val remind: Boolean, val doneWeek: String = "",
    val topic: String = ""
)
data class Question(val id: Long, val subject: String, val note: String, val day: String, val solved: Boolean = false)

fun weekStart(): String = LocalDate.now().with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY)).toString()

const val DATES_URL = "https://raw.githubusercontent.com/boxtvpro2112/Zekam/main/tarihler.json"

class Data(context: Context) {
    private val app = context.applicationContext
    private val sp = context.getSharedPreferences("calisma_data", Context.MODE_PRIVATE)
    val sessions = mutableStateListOf<Session>()
    val tasks = mutableStateListOf<Task>()
    val events = mutableStateListOf<Event>()
    val examDates = mutableStateMapOf<String, String>()
    val modes = mutableStateMapOf<String, String>()
    var syncState by mutableIntStateOf(0)   // 0: kontrol ediliyor, 1: internetten alındı, 2: internet yok
        private set
    val questions = mutableStateListOf<Question>()
    val blocks = mutableStateListOf<Block>()
    private val dir = File(context.filesDir, "questions").apply { mkdirs() }
    fun imageFile(id: Long): File = File(dir, "$id.jpg")

    init {
        runCatching {
            val a = JSONArray(sp.getString("sessions", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                sessions.add(Session(o.getString("s"), o.getInt("n"), o.getString("d")))
            }
        }
        runCatching {
            val a = JSONArray(sp.getString("tasks", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                tasks.add(Task(o.getLong("i"), o.getString("t"), o.getBoolean("x")))
            }
        }
        runCatching {
            val a = JSONArray(sp.getString("events", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                events.add(Event(o.getLong("i"), o.getString("t"), o.getString("d")))
            }
        }
        runCatching {
            val a = JSONArray(sp.getString("questions", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                questions.add(Question(o.getLong("i"), o.getString("s"), o.getString("n"), o.getString("d"), o.optBoolean("v", false)))
            }
        }
        runCatching {
            val a = JSONArray(sp.getString("blocks", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                blocks.add(Block(o.getLong("i"), o.getInt("d"), o.getInt("s"), o.getInt("e"),
                    o.getString("t"), o.getBoolean("r"), o.optString("w", ""), o.optString("c", "")))
            }
        }
        Exam.values().forEach { e ->
            sp.getString("date_" + e.name, null)?.let { examDates[e.name] = it }
            sp.getString("mode_" + e.name, null)?.let { modes[e.name] = it }
        }
    }

    private fun save() {
        val s = JSONArray()
        sessions.forEach { s.put(JSONObject().put("s", it.subject).put("n", it.seconds).put("d", it.day)) }
        val t = JSONArray()
        tasks.forEach { t.put(JSONObject().put("i", it.id).put("t", it.text).put("x", it.done)) }
        val e = JSONArray()
        events.forEach { e.put(JSONObject().put("i", it.id).put("t", it.title).put("d", it.day)) }
        val bl = JSONArray()
        blocks.forEach { bl.put(JSONObject().put("i", it.id).put("d", it.day).put("s", it.start).put("e", it.end).put("t", it.title).put("r", it.remind).put("w", it.doneWeek).put("c", it.topic)) }
        val q = JSONArray()
        questions.forEach { q.put(JSONObject().put("i", it.id).put("s", it.subject).put("n", it.note).put("d", it.day).put("v", it.solved)) }
        sp.edit().putString("blocks", bl.toString()).putString("questions", q.toString()).putString("sessions", s.toString()).putString("tasks", t.toString())
            .putString("events", e.toString()).apply()
    }

    fun addSession(subject: String, seconds: Int) {
        sessions.add(Session(subject, seconds, LocalDate.now().toString())); save()
    }
    fun addTask(text: String) { tasks.add(0, Task(System.currentTimeMillis(), text, false)); save() }
    fun toggleTask(id: Long) {
        val i = tasks.indexOfFirst { it.id == id }
        if (i >= 0) { tasks[i] = tasks[i].copy(done = !tasks[i].done); save() }
    }
    fun removeTask(id: Long) { tasks.removeAll { it.id == id }; save() }
    fun addEvent(title: String, day: String) {
        val e = Event(System.currentTimeMillis(), title, day)
        events.add(e); save()
        Reminders.schedule(app, e)
    }
    fun removeEvent(id: Long) { events.removeAll { it.id == id }; save(); Reminders.cancel(app, id) }
    fun addQuestion(id: Long, subject: String, note: String) {
        questions.add(Question(id, subject, note, LocalDate.now().toString())); save()
    }
    fun toggleSolved(id: Long) {
        val i = questions.indexOfFirst { it.id == id }
        if (i >= 0) { questions[i] = questions[i].copy(solved = !questions[i].solved); save() }
    }
    fun removeQuestion(id: Long) {
        questions.removeAll { it.id == id }
        imageFile(id).delete()
        save()
    }
    fun addBlock(day: Int, start: Int, end: Int, title: String, remind: Boolean, topic: String = "") {
        val b = Block(System.currentTimeMillis(), day, start, end, title, remind, topic = topic)
        blocks.add(b); save()
        Reminders.scheduleBlock(app, b)
    }
    fun updateBlock(id: Long, day: Int, start: Int, end: Int, title: String, remind: Boolean, topic: String = "") {
        val i = blocks.indexOfFirst { it.id == id }
        if (i >= 0) {
            Reminders.cancelBlock(app, id)
            val old = blocks[i]
            blocks[i] = old.copy(day = day, start = start, end = end, title = title,
                remind = remind, topic = topic)
            save()
            Reminders.scheduleBlock(app, blocks[i])
        }
    }
    fun removeBlock(id: Long) { blocks.removeAll { it.id == id }; save(); Reminders.cancelBlock(app, id) }
    fun toggleBlock(id: Long) {
        val i = blocks.indexOfFirst { it.id == id }
        if (i >= 0) {
            val b = blocks[i]
            blocks[i] = b.copy(doneWeek = if (b.doneWeek == weekStart()) "" else weekStart()); save()
        }
    }

    fun useAuto(exam: Exam) {
        modes.remove(exam.name)
        sp.edit().remove("mode_" + exam.name).apply()
    }

    /** Resmi sınav tarihlerini internetten alır. İnternet yoksa kayıtlı tarih kalır. */
    suspend fun syncOnline() {
        val json = withContext(Dispatchers.IO) {
            runCatching {
                val c = URL(DATES_URL).openConnection() as HttpURLConnection
                c.connectTimeout = 6000
                c.readTimeout = 6000
                val text = c.inputStream.bufferedReader().use { it.readText() }
                c.disconnect()
                JSONObject(text)
            }.getOrNull()
        }
        if (json == null) { syncState = 2; return }
        Exam.values().forEach { e ->
            val iso = json.optString(e.name, "")
            val valid = iso.isNotEmpty() && runCatching { LocalDate.parse(iso) }.isSuccess
            if (valid && modes[e.name] != "manual") {
                examDates[e.name] = iso
                sp.edit().putString("date_" + e.name, iso).apply()
            }
        }
        syncState = 1
        CountdownWidget.refresh(app)
    }

    fun chooseExamDate(exam: Exam, iso: String) {
        examDates[exam.name] = iso
        modes[exam.name] = "manual"
        sp.edit().putString("date_" + exam.name, iso).putString("mode_" + exam.name, "manual").apply()
        CountdownWidget.refresh(app)
    }
}
