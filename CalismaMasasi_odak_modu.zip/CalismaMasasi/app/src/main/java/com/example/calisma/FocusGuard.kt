package com.example.calisma

import android.Manifest
import android.app.AppOpsManager
import android.app.Notification
import android.app.NotificationManager
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.Process
import android.provider.Settings
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat

/** Engelleme olunca arayüze haber verir (MainShell sekmeyi Çalışma'ya çevirir). */
object FocusBus {
    var tick by mutableIntStateOf(0)
}

/** Odak modu için gereken izinlerin durumu ve ilgili ayar ekranlarını açan intent'ler. */
object FocusPerms {
    /** 1) Kullanım erişimi: hangi uygulamanın ön planda olduğunu görmek için. */
    fun hasUsage(ctx: Context): Boolean {
        val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        @Suppress("DEPRECATION")
        val mode = if (Build.VERSION.SDK_INT >= 29)
            ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
        else ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
        return mode == AppOpsManager.MODE_ALLOWED
    }

    /** 2) Diğer uygulamaların üzerinde göster: arka plandan Çalışma Masası'nı öne getirmek için. */
    fun hasOverlay(ctx: Context): Boolean = Settings.canDrawOverlays(ctx)

    /** 3) Bildirim: odak modu çalışırken görünen sabit bildirim için (Android 13+). */
    fun hasNotif(ctx: Context): Boolean =
        if (Build.VERSION.SDK_INT >= 33)
            ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        else (ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).areNotificationsEnabled()

    fun allGranted(ctx: Context) = hasUsage(ctx) && hasOverlay(ctx) && hasNotif(ctx)

    fun usageIntent(ctx: Context): Intent =
        Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS, Uri.parse("package:${ctx.packageName}"))

    fun overlayIntent(ctx: Context): Intent =
        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}"))

    fun notifSettingsIntent(ctx: Context): Intent =
        Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName)

    fun open(ctx: Context, intent: Intent, fallback: Intent? = null) {
        val i = Intent(intent).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { ctx.startActivity(i) } catch (_: Exception) {
            if (fallback != null) runCatching { ctx.startActivity(Intent(fallback).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        }
    }
}

object FocusGuard {
    fun start(ctx: Context) {
        ContextCompat.startForegroundService(ctx, Intent(ctx, FocusGuardService::class.java))
    }
    fun stop(ctx: Context) {
        ctx.stopService(Intent(ctx, FocusGuardService::class.java))
    }
}

/**
 * Odak modu açıkken ön plandaki uygulamayı izler. Engellenen bir uygulama açılırsa
 * Çalışma Masası'nı hemen öne getirir. Odak modu kapanınca servis durdurulur.
 */
class FocusGuardService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private var current: String? = null
    private var lastQuery = 0L
    private var lastBlockAt = 0L

    private val tick = object : Runnable {
        override fun run() {
            try { check() } catch (_: Exception) { }
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            handler.postDelayed(this, if (pm.isInteractive) 400L else 2000L)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Notifs.ensureChannels(this)
        val n = Notification.Builder(this, Notifs.FOCUS)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("Odak modu açık")
            .setContentText("Seçtiğin uygulamalar engelleniyor")
            .setOngoing(true)
            .setContentIntent(Notifs.openApp(this))
            .build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(FOCUS_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(FOCUS_ID, n)

        handler.removeCallbacks(tick)
        current = null
        lastQuery = System.currentTimeMillis() - 10_000L
        handler.post(tick)
        return START_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        super.onDestroy()
    }

    private fun check() {
        if (!FocusPerms.hasUsage(this)) return
        val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        val events = usm.queryEvents(lastQuery, now)
        val e = UsageEvents.Event()
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            @Suppress("DEPRECATION")
            if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) current = e.packageName
        }
        lastQuery = now - 500L

        val pkg = current ?: return
        if (pkg == packageName) return
        val blocked = getSharedPreferences("focus", Context.MODE_PRIVATE)
            .getStringSet("blocked", emptySet())?.toSet() ?: emptySet()
        if (pkg !in blocked) return
        if (now - lastBlockAt < 800L) return
        lastBlockAt = now

        val label = runCatching {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        }.getOrDefault(pkg)

        val back = Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        runCatching { startActivity(back) }
        FocusBus.tick++
        Toast.makeText(this, "Odak modu açık: $label engellendi", Toast.LENGTH_SHORT).show()
        current = packageName
    }

    companion object { private const val FOCUS_ID = 1002 }
}
