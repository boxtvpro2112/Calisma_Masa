package com.example.calisma

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

enum class Exam(val label: String) { LGS("LGS"), YKS("YKS") }
enum class Mode(val label: String) { SYSTEM("Sistem"), LIGHT("Açık"), DARK("Koyu") }

class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("calisma", Context.MODE_PRIVATE)
    private val app = context.applicationContext

    var exam by mutableStateOf(sp.getString("exam", null)?.let { runCatching { Exam.valueOf(it) }.getOrNull() })
        private set
    var mode by mutableStateOf(runCatching { Mode.valueOf(sp.getString("mode", "SYSTEM")!!) }.getOrDefault(Mode.SYSTEM))
        private set
    var accent by mutableStateOf(sp.getInt("accent", 0).coerceIn(0, Accents.size - 1))
        private set

    private val fsp = context.getSharedPreferences("focus", Context.MODE_PRIVATE)
    var blocked by mutableStateOf(fsp.getStringSet("blocked", emptySet())?.toSet() ?: emptySet())
        private set
    var focusConfigured by mutableStateOf(fsp.getBoolean("configured", false))
        private set
    var focusOn by mutableStateOf(fsp.getBoolean("on", false))
        private set
    fun saveBlocked(s: Set<String>) { blocked = s.toSet(); fsp.edit().putStringSet("blocked", HashSet(s)).apply() }
    fun markFocusConfigured() { focusConfigured = true; fsp.edit().putBoolean("configured", true).apply() }
    fun setFocus(v: Boolean) { focusOn = v; fsp.edit().putBoolean("on", v).apply() }

    fun chooseExam(e: Exam?) { exam = e; sp.edit().apply { if (e == null) remove("exam") else putString("exam", e.name) }.apply(); CountdownWidget.refresh(app) }
    fun chooseMode(m: Mode) { mode = m; sp.edit().putString("mode", m.name).apply() }
    fun chooseAccent(i: Int) { accent = i; sp.edit().putInt("accent", i).apply() }
}
