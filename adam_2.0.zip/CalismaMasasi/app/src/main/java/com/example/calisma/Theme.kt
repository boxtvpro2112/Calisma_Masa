package com.example.calisma

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class AccentColor(val name: String, val light: Color, val dark: Color)

val Accents = listOf(
    AccentColor("Mavi", Color(0xFF3B5BFF), Color(0xFF9DB4FF)),
    AccentColor("Yeşil", Color(0xFF12926A), Color(0xFF8FDDB5)),
    AccentColor("Mor", Color(0xFF7C4DFF), Color(0xFFCBB2FF)),
    AccentColor("Turuncu", Color(0xFFE0641A), Color(0xFFFFB98A)),
)

private val AppShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(32.dp)
)

private fun appTypography(): Typography {
    val b = Typography()
    return b.copy(
        headlineMedium = b.headlineMedium.copy(fontWeight = FontWeight.Bold, letterSpacing = (-0.6).sp),
        titleLarge = b.titleLarge.copy(fontWeight = FontWeight.Bold, letterSpacing = (-0.3).sp),
        titleMedium = b.titleMedium.copy(fontWeight = FontWeight.SemiBold),
        labelLarge = b.labelLarge.copy(fontWeight = FontWeight.SemiBold, letterSpacing = 0.2.sp),
        labelMedium = b.labelMedium.copy(fontWeight = FontWeight.SemiBold, letterSpacing = 0.6.sp)
    )
}

/** Kartların ince çerçevesi. */
@Composable
fun cardBorder(): BorderStroke = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)

/** Seçili olunca vurgu renginin yumuşak tonunu alan modern çip. */
@Composable
fun AppChip(selected: Boolean, onClick: () -> Unit, label: @Composable () -> Unit, enabled: Boolean = true) {
    FilterChip(
        selected = selected, onClick = onClick, label = label, enabled = enabled,
        shape = RoundedCornerShape(12.dp),
        colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
            selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
        )
    )
}

@Composable
fun AppTheme(prefs: Prefs, content: @Composable () -> Unit) {
    val dark = when (prefs.mode) {
        Mode.SYSTEM -> isSystemInDarkTheme()
        Mode.LIGHT -> false
        Mode.DARK -> true
    }
    val a = Accents[prefs.accent]
    val scheme = if (dark) {
        val bg = Color(0xFF0E0F13)
        darkColorScheme(
            primary = a.dark, onPrimary = Color(0xFF101114),
            primaryContainer = lerp(bg, a.dark, 0.20f), onPrimaryContainer = a.dark,
            secondaryContainer = Color(0xFF262830), onSecondaryContainer = Color(0xFFE8E9EC),
            background = bg, surface = bg,
            surfaceVariant = Color(0xFF1A1C22), onSurfaceVariant = Color(0xFFA7AAB5),
            onBackground = Color(0xFFEDEEF1), onSurface = Color(0xFFEDEEF1),
            outline = Color(0xFF454853), outlineVariant = Color(0xFF2A2C34),
            surfaceContainerLowest = Color(0xFF0A0B0E), surfaceContainerLow = Color(0xFF14151A),
            surfaceContainer = Color(0xFF1A1C22), surfaceContainerHigh = Color(0xFF212329),
            surfaceContainerHighest = Color(0xFF282A32)
        )
    } else {
        val bg = Color(0xFFF4F5FA)
        lightColorScheme(
            primary = a.light, onPrimary = Color.White,
            primaryContainer = lerp(Color.White, a.light, 0.13f), onPrimaryContainer = a.light,
            secondaryContainer = Color(0xFFE6E9F2), onSecondaryContainer = Color(0xFF15171B),
            background = bg, surface = bg,
            surfaceVariant = Color.White, onSurfaceVariant = Color(0xFF666A76),
            onBackground = Color(0xFF14161B), onSurface = Color(0xFF14161B),
            outline = Color(0xFFB9BDC9), outlineVariant = Color(0xFFE3E6EE),
            surfaceContainerLowest = Color.White, surfaceContainerLow = Color(0xFFFAFBFE),
            surfaceContainer = Color.White, surfaceContainerHigh = Color.White,
            surfaceContainerHighest = Color(0xFFECEEF5)
        )
    }
    MaterialTheme(colorScheme = scheme, shapes = AppShapes, typography = appTypography(), content = content)
}
