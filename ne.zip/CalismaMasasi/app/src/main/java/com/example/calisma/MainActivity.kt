package com.example.calisma

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val prefs = Prefs(this)
        val data = Data(this)
        setContent {
            AppTheme(prefs) {
                if (prefs.exam == null) ExamPicker(prefs) else MainShell(prefs, data)
            }
        }
    }
}
