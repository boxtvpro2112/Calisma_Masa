package com.example.calisma

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class AccentColor(val name: String, val light: Color, val dark: Color)

val Accents = listOf(
    AccentColor("Mavi", Color(0xFF3B5BFF), Color(0xFF9DB4FF)),
    AccentColor("Yeşil", Color(0xFF12926A), Color(0xFF8FDDB5)),
    AccentColor("Mor", Color(0xFF7C4DFF), Color(0xFFCBB2FF)),
    AccentColor("Turuncu", Color(0xFFE0641A), Color(0xFFFFB98A)),
)

private val AppShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(32.dp)
)

private fun appTypography(): Typography {
    val b = Typography()
    return b.copy(
        headlineMedium = b.headlineMedium.copy(fontWeight = FontWeight.Bold, letterSpacing = (-0.6).sp),
        titleLarge = b.titleLarge.copy(fontWeight = FontWeight.Bold, letterSpacing = (-0.3).sp),
        titleMedium = b.titleMedium.copy(fontWeight = FontWeight.SemiBold),
        labelLarge = b.labelLarge.copy(fontWeight = FontWeight.SemiBold, letterSpacing = 0.2.sp),
        labelMedium = b.labelMedium.copy(fontWeight = FontWeight.SemiBold, letterSpacing = 0.6.sp)
    )
}

/** Kartların ince çerçevesi. */
@Composable
fun cardBorder(): BorderStroke {
    val c = MaterialTheme.colorScheme.outlineVariant
    return BorderStroke(1.dp, Brush.linearGradient(listOf(c, c.copy(alpha = c.alpha * 0.35f), c)))
}

/** Seçili olunca vurgu renginin yumuşak tonunu alan modern çip. */
@Composable
fun AppChip(selected: Boolean, onClick: () -> Unit, label: @Composable () -> Unit, enabled: Boolean = true) {
    FilterChip(
        selected = selected, onClick = onClick, label = label, enabled = enabled,
        shape = RoundedCornerShape(12.dp),
        colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
            selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
        )
    )
}

@Composable
fun AppTheme(prefs: Prefs, content: @Composable () -> Unit) {
    val dark = when (prefs.mode) {
        Mode.SYSTEM -> isSystemInDarkTheme()
        Mode.LIGHT -> false
        Mode.DARK -> true
    }
    val a = Accents[prefs.accent]
    val scheme = if (dark) {
        val bg = Color(0xFF0E0F13)
        darkColorScheme(
            primary = a.dark, onPrimary = Color(0xFF101114),
            primaryContainer = a.dark.copy(alpha = 0.22f), onPrimaryContainer = a.dark,
            secondaryContainer = Color(0xFF262830), onSecondaryContainer = Color(0xFFE8E9EC),
            background = bg, surface = bg,
            surfaceVariant = Color.White.copy(alpha = 0.08f), onSurfaceVariant = Color(0xFFB4B7C2),
            onBackground = Color(0xFFEDEEF1), onSurface = Color(0xFFEDEEF1),
            outline = Color(0xFF5A5D6A), outlineVariant = Color.White.copy(alpha = 0.22f),
            surfaceContainerLowest = Color(0xFF0A0B0E), surfaceContainerLow = Color(0xFF14151A),
            surfaceContainer = Color(0xFF1A1C22), surfaceContainerHigh = Color(0xFF23252D),
            surfaceContainerHighest = Color(0xFF282A32)
        )
    } else {
        val bg = Color(0xFFF4F5FA)
        lightColorScheme(
            primary = a.light, onPrimary = Color.White,
            primaryContainer = a.light.copy(alpha = 0.16f), onPrimaryContainer = a.light,
            secondaryContainer = Color(0xFFE6E9F2), onSecondaryContainer = Color(0xFF15171B),
            background = bg, surface = bg,
            surfaceVariant = Color.White.copy(alpha = 0.58f), onSurfaceVariant = Color(0xFF5C6070),
            onBackground = Color(0xFF14161B), onSurface = Color(0xFF14161B),
            outline = Color(0xFFB9BDC9), outlineVariant = Color.White.copy(alpha = 0.95f),
            surfaceContainerLowest = Color.White, surfaceContainerLow = Color(0xFFFAFBFE),
            surfaceContainer = Color.White, surfaceContainerHigh = Color.White,
            surfaceContainerHighest = Color(0xFFECEEF5)
        )
    }
    val base = if (dark) listOf(Color(0xFF0B0C12), Color(0xFF141226), Color(0xFF0D1620))
               else listOf(Color(0xFFEEF2FF), Color(0xFFF3ECFF), Color(0xFFFFF0E8))
    val glow1 = (if (dark) a.dark else a.light).copy(alpha = if (dark) 0.34f else 0.38f)
    val glow2 = (if (dark) Color(0xFF7C4DFF) else Color(0xFFFF8FB1)).copy(alpha = if (dark) 0.28f else 0.32f)
    MaterialTheme(colorScheme = scheme, shapes = AppShapes, typography = appTypography()) {
        Box(
            Modifier.fillMaxSize()
                .background(Brush.verticalGradient(base))
                .drawBehind {
                    val w = size.width; val h = size.height
                    drawRect(Brush.radialGradient(listOf(glow1, Color.Transparent), Offset(w * 0.1f, h * 0.08f), w * 0.95f))
                    drawRect(Brush.radialGradient(listOf(glow2, Color.Transparent), Offset(w * 0.95f, h * 0.88f), w * 1.0f))
                }
        ) { content() }
    }
}
